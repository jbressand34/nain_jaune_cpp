
#include"Fonction/Fonction.h"
using namespace std;
int main(int argc,char**argv){
  /*
  Score score1;
  cout<<score1.getpseudo()<<" "<<score1.getscore()<<" "<<score1.getdate()<<endl;
  Score score2=Score("Victor",158);
  cout<<score2.getpseudo()<<" "<<score2.getscore()<<" "<<score2.getdate()<<endl;
  
  if(!(score1.plusgrand(score2))){
    cout<<"victor a gagner"<<endl;
  }*/
  string a="babar";
  string b="barnabe";
  string c="babar1";
  string d="babar2";
  string e="babar3";
  string f="babar4";
  string g="babar5";
  bestscore((size_t)15,a,b);
  return 0;
}
