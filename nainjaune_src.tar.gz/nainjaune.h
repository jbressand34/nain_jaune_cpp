#ifndef Nainjaune_H
#define Nainjaune_H

#include <iostream>
#include <fstream>
#include "Plateau/Plateau.h"
#include <string>
#include <ctime>


#endif
